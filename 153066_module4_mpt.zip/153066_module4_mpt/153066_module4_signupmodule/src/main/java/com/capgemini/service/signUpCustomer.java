package com.capgemini.service;

import java.util.List;

import com.capgemini.model.Customer;

public interface signUpCustomer {
	
	public String addCustomer(Customer customer);
	
	public Customer findCustomerByid(int id);
	
	public List<Customer> getAllCustomerDetails();

}
